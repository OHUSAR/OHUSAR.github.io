from tkinter import *


class Line:
    def __init__(self, x1, y1, x2, y2, fill='black'):
        self.x1 = x1
        self.x2 = x2
        self.y1 = y1
        self.y2 = y2
        self.fill = fill


class CanvasMock(Canvas):

    lines = []

    def create_line(self, *args, **kw):
        super(CanvasMock, self).create_line(*args, **kw)
        x1, y1, x2, y2 = args
        self.lines.append(Line(x1, y1, x2, y2, fill=kw['fill']))


master = Tk()
w = CanvasMock(master, width=200, height=100)
w.pack()

w.create_line(0, 0, 200, 100, fill="black")
w.create_line(0, 100, 200, 0, fill="red")


def assert_line_equals(l1, l2):
    assert l1.x1 == l2.x1
    assert l1.y1 == l2.y1
    assert l1.x2 == l2.x2
    assert l1.y2 == l2.y2
    assert l1.fill == l2.fill

l = Line(0, 0, 200, 100, fill='!!ZLE!!')
assert_line_equals(l, w.lines[0])

w.mainloop()
