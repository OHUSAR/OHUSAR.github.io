from unittest import TestCase


class TTestCase(TestCase):

    def _binary_tree_inorder(self, t):
        q = [t.root]
        result = []
        current_node = t.root
        while q:
            if current_node:
                while current_node.left:
                    q.append(current_node.left)
                    current_node = current_node.left
            popped_node = q.pop()
            current_node = None
            if popped_node:
                result.append(popped_node.value)
                current_node = popped_node.right
                q.append(current_node)
        return result

    def _binary_tree_preorder(self, t):
        q = []
        result = []
        current_node = t.root
        while True:
            while current_node:
                result.append(current_node.value)
                q.append(current_node)
                current_node = current_node.left

            if not q:
                return result

            current_node = q.pop()
            current_node = current_node.right
        return result

    def assertBinaryTreeEqual(self, t1, t2):
        self.assertListEqual(
            self._binary_tree_preorder(t1),
            self._binary_tree_preorder(t2),
            'Tree preorder representation differs'
        )
        self.assertListEqual(
            self._binary_tree_inorder(t1),
            self._binary_tree_inorder(t2),
            'Tree inorder representation differs'
        )


class Tree:
    def __init__(self, root=None):
        self.root = root


class Node:
    def __init__(self, value, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right

if __name__ == '__main__':
    t = TTestCase()

    root_node = Node(1, Node(2, Node(3), Node(4)), Node(5, None, Node(6)))
    root_node2 = Node(1, Node(2, Node(33), Node(4)), Node(5, None, Node(6)))
    tree = Tree(root_node)
    tree2 = Tree(root_node2)
    t.assertBinaryTreeEqual(tree, tree2)




